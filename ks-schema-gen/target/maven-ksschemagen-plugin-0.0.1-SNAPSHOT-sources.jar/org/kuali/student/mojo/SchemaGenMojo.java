package org.kuali.student.mojo;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.kuali.student.schemagen.SchemaGen;
/**
 * Generates schema from annotations
 *
 * @goal schemaGen
 */
public class SchemaGenMojo extends AbstractMojo {
    /**
     * Persistence File Names.
     *
     * @parameter
     */
    private String[] persistenceFileNames;

    /**
     * Output path.
     *
     * @parameter
     */
    private String outputPath;
	
    public SchemaGenMojo() {
		super();
	}
	
	@Override
	public void execute() throws MojoExecutionException, MojoFailureException {
		SchemaGen schemaGen = new SchemaGen(outputPath, persistenceFileNames);
		try {
			schemaGen.generateAllDbTypes();
		} catch (Exception e) {
			throw new RuntimeException("Error generating schema.",e);
		}
	}

	public String[] getPersistenceFileNames() {
		return persistenceFileNames;
	}

	public void setPersistenceFileNames(String[] persistenceFileNames) {
		this.persistenceFileNames = persistenceFileNames;
	}

	public String getOutputPath() {
		return outputPath;
	}

	public void setOutputPath(String outputPath) {
		this.outputPath = outputPath;
	}

}
