package org.kuali.student.brms.factfinder.typekey;

public enum FactParamDefTimeKey {    
    KUALI_FACT_DEFINITION_TIME_KEY, KUALI_FACT_EXECUTION_TIME_KEY;
}
