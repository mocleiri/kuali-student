package org.kuali.student.brms.internal.common.statement.exceptions;

public class IllegalPropositionStateException extends IllegalStateException {

}
