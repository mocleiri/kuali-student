/**
 * 
 */
package org.kuali.student.brms.devgui.client;

/**
 * @author zzraly
 */
public class IllegalRuleFormatException extends IllegalStateException {

    /**
     * @param string
     */
    public IllegalRuleFormatException(String s) {
        super(s);
    }

}
