/**
 * 
 */
package org.kuali.student.brms.internal.common.utils;

/**
 * @author zzraly
 */
public class IllegalRuleFormatException extends IllegalStateException {

    /**
     * @param string
     */
    public IllegalRuleFormatException(String s) {
        super(s);
    }

}
