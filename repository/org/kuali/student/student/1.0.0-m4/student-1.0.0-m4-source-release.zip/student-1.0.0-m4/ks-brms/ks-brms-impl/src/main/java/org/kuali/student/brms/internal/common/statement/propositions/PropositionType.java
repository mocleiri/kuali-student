package org.kuali.student.brms.internal.common.statement.propositions;

public enum PropositionType {
	SIMPLECOMPARABLE, INTERSECTION, SUBSET, SUM, AVERAGE, MIN, MAX, CHAIN
}
